// Copyright Google 2013. All Rights Reserved.

window.addEventListener('load', function load(event){
  var app = new ChromeConnectivityDebugger();
},false);
