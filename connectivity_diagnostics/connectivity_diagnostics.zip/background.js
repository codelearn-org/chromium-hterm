// Copyright 2013 Google Inc. All Rights Reserved.


/**
 * @fileoverview Chrome v2 packaged app background script.
 * @author ebeach@google.com (Eric Beach)
 */


/**
 * Listens for the app launching then creates the window
 *
 * @see http://developer.chrome.com/trunk/apps/app.runtime.html
 * @see http://developer.chrome.com/trunk/apps/app.window.html
 */
chrome.app.runtime.onLaunched.addListener(function() {
  var width = screen.width * 0.8;
  var height = screen.height * 0.8;
  chrome.app.window.create('index.html',
      {width: width, height: height});
});