

/**
 * @fileoverview Enum to store the type of a hostname.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.HostType');


/**
 * @enum {number}
 */
ccd.HostType = {
  GOOGLE: 0,
  EXTERNAL: 1
};
