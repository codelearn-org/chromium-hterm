

/**
 * @fileoverview Test whether ChromeOS version is up to date.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.ChromeOSVersionTest');


goog.require('ccd.Test');
goog.require('ccd.TestId');
goog.require('ccd.TestResult');
goog.require('ccd.TestVerdict');



/**
 * Test the version of ChromeOS.
 * @constructor
 * @extends {ccd.Test}
 */
ccd.ChromeOSVersionTest = function() {
  goog.base(this);
  this.testResult = new ccd.TestResult(ccd.TestId.CHROMEOS_VERSION);

  /**
   * @private {number}
   */
  this.shortPlatformNumber_ = 0;
};
goog.inherits(ccd.ChromeOSVersionTest, ccd.Test);


/**
 * The smallest permitted version of ChromeOS.
 * @type {number}
 * @const
 */
ccd.ChromeOSVersionTest.SMALLEST_PERMITTED_CHROMEOS_PLATFORM_NUM = 3912;


/**
 * Return the browser's user-agent.
 * This is implemented for testing purposes.
 * @return {string} Browser's user-agent.
 * @private
 */
ccd.ChromeOSVersionTest.prototype.getUserAgent_ = function() {
  return navigator.userAgent;
};


/**
 * Analyze the test results.
 * @override
 */
ccd.ChromeOSVersionTest.prototype.analyzeResults = function() {
  if (this.shortPlatformNumber_ <
      ccd.ChromeOSVersionTest.SMALLEST_PERMITTED_CHROMEOS_PLATFORM_NUM) {
    this.testResult.setTitle('ChromeOS Out of Date');
    this.testResult.setSubtitle('You are not using the most recent version ' +
        'of ChromeOS. Consequently, you do not have all known updates and ' +
        'you might therefore experience connectivity problems. Instructions ' +
        'for upgrading ChromeOS are available by clicking "More Information".');
    this.testResult.setTestVerdict(ccd.TestVerdict.PROBLEM);
    this.testResult.addLogRecord('ChromeOS Version Test detected a problem. ' +
        'ChromeOS Version ' + this.shortPlatformNumber_ +
        ' is out of date. Minimum version is now ' +
        ccd.ChromeOSVersionTest.SMALLEST_PERMITTED_CHROMEOS_PLATFORM_NUM);
  } else {
    this.testResult.setTitle('ChromeOS is Up to Date');
    this.testResult.setSubtitle('You are using a recent version of ' +
        'ChromeOS and therefore you have all known fixes for connectivity ' +
        'issues.');
    this.testResult.setTestVerdict(ccd.TestVerdict.NO_PROBLEM);
    this.testResult.addLogRecord('ChromeOS Version Test did not detect a ' +
        'problem. ChromeOS Version ' + this.shortPlatformNumber_ +
        ' is up to date. Minimum version is now ' +
        ccd.ChromeOSVersionTest.SMALLEST_PERMITTED_CHROMEOS_PLATFORM_NUM);
  }
};


/**
 * @override
 */
ccd.ChromeOSVersionTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;
  var userAgent = this.getUserAgent_();
  this.testResult.addLogRecord('Browser User-Agent: ' + userAgent);

  var fullPlatformNumber = this.getFullPlatformNum_(userAgent);
  this.testResult.addLogRecord('Full ChromeOS Platform Number Parsed: ' +
      fullPlatformNumber);

  this.shortPlatformNumber_ = this.getShortPlatformNum_(userAgent);
  this.testResult.addLogRecord('Short ChromeOS Platform Number Parsed: ' +
      this.shortPlatformNumber_);

  this.analyzeResults();

  this.executeCallback();
};


/**
 * Take the full user agent and return the full platform number of ChromeOS.
 * @param {string} userAgent Browser's user agent string.
 * @return {string} Full ChromeOS number (e.g., "3912.23.0").
 * @private
 */
ccd.ChromeOSVersionTest.prototype.getFullPlatformNum_ = function(userAgent) {
  var fullPlatformNumArr = userAgent.match(/CrOS [a-zA-Z0-9_]+ ([0-9\.]+)\)/);
  if (fullPlatformNumArr == null || fullPlatformNumArr.length != 2) {
    return '-1';
  }

  var fullPlatformNum = fullPlatformNumArr[1];
  return fullPlatformNum;
};


/**
 * @param {string} userAgent Browser's user agent string.
 * @return {number} Short ChromeOS version number (e.g., 3912).
 * @private
 */
ccd.ChromeOSVersionTest.prototype.getShortPlatformNum_ = function(userAgent) {
  var fullPlatformNumArr = userAgent.match(/CrOS [a-zA-Z0-9_]+ ([0-9\.]+)\)/);
  if (fullPlatformNumArr == null || fullPlatformNumArr.length != 2) {
    return -1;
  }

  var fullPlatformNum = fullPlatformNumArr[1];
  var shortPlatformNum = fullPlatformNum.substr(0,
                                                fullPlatformNum.indexOf('.'));
  return parseInt(shortPlatformNum, 10);
};
