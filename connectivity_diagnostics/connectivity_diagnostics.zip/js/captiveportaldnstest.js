// Copyright 2013 Google Inc. All Rights Reserved.


/**
 * @fileoverview Test whether a captive portal is present and implemented
 *   via DNS.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.CaptivePortalDnsTest');

goog.require('ccd.Test');
goog.require('ccd.TestId');
goog.require('ccd.TestResult');
goog.require('ccd.TestVerdict');



/**
 * Test whether a captive portal is present and implemented by DNS.
 * @constructor
 * @extends {ccd.Test}
 */
ccd.CaptivePortalDnsTest = function() {
  goog.base(this);
  this.testResult = new ccd.TestResult(ccd.TestId.CAPTIVE_PORTAL_DNS);
  this.numTestsCompleted_ = 0;
  this.resolutionResultsString_ = new Array();
  this.resolutionResultsCode_ = new Array();
};
goog.inherits(ccd.CaptivePortalDnsTest, ccd.Test);


/**
 * The number of hostnames that have been tested to detemine whether a
 *   captive portal is present.
 * @type {number}
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.numTestsCompleted_ = 0;


/**
 * @type {number}
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.timeoutId_ = 0;


/**
 * @type {Array.<number>}
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.resolutionResultsCode_ = null;


/**
 * @type {Array.<string>}
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.resolutionResultsString_ = null;


/**
 * Call the callback function.
 */
ccd.CaptivePortalDnsTest.prototype.executeCallback = function() {
  this.callbackFnc(this.testResult);
};


/**
 * Analyze test results.
 */
ccd.CaptivePortalDnsTest.prototype.analyzeResults = function() {
  // assume no problem; change/update this if things change
  this.testResult.setTestVerdict(ccd.TestVerdict.NO_PROBLEM);
  this.testResult.setTitle('Internet Traffic Not Blocked by ' +
      'Captive Portal (DNS)');
  this.testResult.setSubtitle('No captive portal found. A captive portal is ' +
      'a website that a network requires its users to view and interact ' +
      'with before being granted access to browse the Internet freely.');

  // check whether two known hosts resolve to the same IP as a
  //   random hostname; if so, there is likely a captive portal
  if (this.resolutionResultsString_[0] ==
      this.resolutionResultsString_[1] ==
      this.resolutionResultsString_[2]) {
    this.testResult.setTestVerdict(ccd.TestVerdict.PROBLEM);
    this.testResult.setTitle('Internet Traffic Blocked by ' +
        'Captive Portal (DNS)');
    this.testResult.setSubtitle('A captive portal is a website that a ' +
        'network requires its users to view and interact with before being ' +
        'granted access to browse the Internet freely. A captive portal was ' +
        'found on your network, meaning unrestricted access to the Internet ' +
        'is blocked. You can learn more about how to fix this by clicking ' +
        '"More Information".');
    this.testResult.addLogRecord('DNS-based captive portal detected as two ' +
        'known hostnames and a random unknown hostname all resolve to the ' +
        'same IP. Random Hostname: ' + this.resolutionResultsString_[2] +
        '. Known Hostname: ' + this.resolutionResultsString_[1]);
  } else {
    this.testResult.addLogRecord('Two Google hostnames resolve to different ' +
        'IPs than a random hostname.');

    // check the random hosts; see if they do not resolve all to the same thing
    // unfortuantely, we cannot check to see if they resolve as some ISPs
    //   will have a DNS not found landing page (e.g. the IP for
    //   http://search.dnsassist.verizon.net is returned on Verizon for
    //   hostnames that don't exist)
    for (var i = 3; i < this.resolutionResultsString_.length; i++) {
      // in testing, some ISPs did not consistently return the IP of a
      //   search page even for hostnames that did not exist.
      // consequently, two IPs that differ will be marked as a warning
      //   and not a failure
      if (this.resolutionResultsString_[i] !=
          this.resolutionResultsString_[i - 1]) {
        this.testResult.setTitle('Internet Traffic May be Blocked by ' +
            'Captive Portal (DNS)');
        this.testResult.setSubtitle('A captive portal is a website that a ' +
            'network requires its users to view and interact with before ' +
            'being granted access to browse the Internet freely. A captive ' +
            'portal appears to be on your network, meaning unrestricted ' +
            'access to the Internet is probably blocked. You can learn more ' +
            'about this as well as how to fix it by clicking ' +
            '"More Information".');
        this.testResult.addLogRecord('DNS-based captive portal possible as ' +
            'two random hostnames resolved successfully to two different ' +
            'IPs: ' + this.resolutionResultsString_[i] + ' and ' +
            this.resolutionResultsString_[i - 1]);

        this.testResult.setTestVerdict(ccd.TestVerdict.POTENTIAL_PROBLEM);
        break;
      }

      if (this.resolutionResultsCode_[i] == 0) {
        // in theory, result code should always be -105 since these hostnames
        //   do not exist. however, some networks serve the IP of a search
        //   page for all hostnames that don't exist, meaning we could
        //   legitimately get a resultCode == 0 and not have a captive portal
        this.testResult.setTitle('Internet Traffic May be Blocked by ' +
            'Captive Portal (DNS)');
        this.testResult.addLogRecord('DNS-based captive portal possible as ' +
            'a random hostnam resolved successfully with hostname ' +
            this.resolutionResultsString_[i] + ' and status code ' +
            this.resolutionResultsCode_[i]);
        this.testResult.setTestVerdict(ccd.TestVerdict.POTENTIAL_PROBLEM);
      }
    }
  }
};


/**
 * See chromium/src/chrome/common/extensions/api/experimental_dns.idl for
 *   the definition of ResolveCallbackResolveInfo.
 * @param {chrome.experimental.dns.ResolveCallbackResolveInfo} resolverResult
 *   DNS query results.
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.resolveCallback_ = function(resolverResult) {
  if (resolverResult == undefined || resolverResult.resultCode == undefined) {
    // resolution failed
    this.testResult.addLogRecord('Test Hostname #' + this.numTestsCompleted_ +
        '; No result status code; Aborting test due to test failure.');

    this.executeCallback();
  } else {
    // test succeeded (i.e., we got a result info we can analyze)
    this.resolutionResultsCode_.push(resolverResult.resultCode);
    this.testResult.addLogRecord('Test Hostname #' + this.numTestsCompleted_ +
        '; Resolved Status Code: ' + resolverResult.resultCode);

    // for some resolvers, resolverResult.address will be blank
    // check for this situation
    if (resolverResult.address != undefined) {
      this.resolutionResultsString_.push(resolverResult.address);
      this.testResult.addLogRecord('Test Hostname #' + this.numTestsCompleted_ +
          '; Resolved Address: ' + resolverResult.address);
    } else {
      // need to push null in order to guarantee the array contains
      //   the proper number of elements, which preserves indexing
      this.resolutionResultsString_.push(null);
      this.testResult.addLogRecord('Test Hostname #' + this.numTestsCompleted_ +
          '; Resolved Status Code: no address field returned (set to null)');
    }
  }

  this.numTestsCompleted_++;

  var numTestsToRun = ccd.TestConfVars.NUM_HOSTS_CAPTIVE_PORTAL_DNS_TEST;
  window.clearTimeout(this.timeoutId_);
  if (this.numTestsCompleted_ >= numTestsToRun) {
    this.analyzeResults();
    this.executeCallback();
  } else {
    this.timeoutId_ = setTimeout(this.attemptResolution_.bind(this),
        ccd.TestConfVars.CAPTIVE_PORTAL_DNS_SLEEP_MILSEC);
  }
};


/**
 * @private
 */
ccd.CaptivePortalDnsTest.prototype.attemptResolution_ = function() {
  var hostname = '';
  if (this.numTestsCompleted_ == 0) {
    hostname = 'mail.google.com';
  } else if (this.numTestsCompleted_ == 1) {
    hostname = 'www.google.com';
  } else {
    var possibleChars = 'abcdefghijklmnopqrstuvwxyz';
    for (var i = 0; i < 20; i++) {
      var rand = Math.floor(Math.random() * possibleChars.length);
      hostname += possibleChars.charAt(rand);
    }
    hostname += '.com';
  }
  this.testResult.addLogRecord('Test Hostname #' + this.numTestsCompleted_ +
      '; Attempting to resolve hostname: ' + hostname);

  // TODO: for testing, just stub this function
  chrome.experimental.dns.resolve(hostname,
                                  this.resolveCallback_.bind(this));
};


/**
 * @param {function(this:ccd.TestsManager, ccd.TestResult)} callbackFnc
 *   Function to execute upon completion of test.
 */
ccd.CaptivePortalDnsTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;
  this.attemptResolution_();
};
