// Copyright 2013 Google Inc. All Rights Reserved.


/**
 * @fileoverview  Manage the GUI
 * The GUI is organized in a hierarchical manner:
 *  - main
 *  -- header
 *  -- contents
 *  --- start-frame
 *  --- results-frame
 *  ---- results-failing-frame
 *  ----- test-result-frame-{n}
 *  ----- test-result-frame-{n}
 *  ----- test-result-frame-{n}
 *  ---- results-warning-frame
 *  ----- test-result-frame-{n}
 *  ----- test-result-frame-{n}
 *  ---- results-passing-frame
 *  ----- test-result-frame-{n}
 *  Within each test result frame, logs are available as well as next steps.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.GuiManager');

goog.require('Spinner');
goog.require('ccd.TestVerdict');
goog.require('ccd.TestsManager');



/**
 * @constructor
 */
ccd.GuiManager = function() {};


/**
 * Construct the test-results-frame for a specific test result.
 * This will construct a div to encapsulate all information for printing
 *   the resutls of a given test.
 * @param {ccd.TestResult} testResult Results from test to be framed.
 * @private
 */
ccd.GuiManager.prototype.paintResultFrame_ = function(testResult) {
  var testResultFrameId = 'test-result-frame-' + testResult.getTestId();
  if (document.getElementById(testResultFrameId) != undefined) return;

  var parentElementId = '';
  switch (testResult.getTestVerdict()) {
    case ccd.TestVerdict.NO_PROBLEM:
      parentElementId = this.testsResultsPassingFrameId_;
      break;
    case ccd.TestVerdict.POTENTIAL_PROBLEM:
      parentElementId = this.testsResultsWarningFrameId_;
      break;
    case ccd.TestVerdict.PROBLEM:
      parentElementId = this.testsResultsFailingFrameId_;
      break;
  }

  var resultFrame = document.createElement('div');
  resultFrame.id = testResultFrameId;

  document.getElementById(parentElementId).appendChild(resultFrame);
};


/**
 * Fill in the details of the results of a given test.
 * @param {ccd.TestResult} testResult Result to paint within extant frame.
 * @private
 */
ccd.GuiManager.prototype.paintTestResult_ = function(testResult) {
  var testResultFrameId = 'test-result-frame-' + testResult.getTestId();
  if (document.getElementById(testResultFrameId) == undefined) {
    this.paintResultFrame_(testResult);
  } else {
    return;
  }

  // Set Verdict-Specific Variables
  var titleClassName = '';
  var titleHtml = testResult.getTitle();
  var subtitleText = testResult.getSubtitle();
  switch (testResult.getTestVerdict()) {
    case ccd.TestVerdict.NO_PROBLEM:
      titleClassName = 'test-title test-verdict-pass';
      break;
    case ccd.TestVerdict.POTENTIAL_PROBLEM:
      titleClassName = 'test-title test-verdict-warning';
      break;
    case ccd.TestVerdict.PROBLEM:
      titleClassName = 'test-title test-verdict-fail';
      break;
  }

  // Create Test Title
  var title = document.createElement('div');
  title.className = titleClassName;
  title.innerHTML = titleHtml;
  document.getElementById(testResultFrameId).appendChild(title);

  // Create Test Subtitle
  var testSubtitle = document.createElement('div');
  testSubtitle.id = 'test-subtitle-' + testResult.getTestId();
  testSubtitle.innerHTML = subtitleText;
  testSubtitle.className = 'test-subtitle';
  document.getElementById(testResultFrameId).appendChild(testSubtitle);

  // Option to Show More Information
  var toggleShowMoreInformation = function(testId) {
    var miDom = document.getElementById(
        'more-info-container-' + testResult.getTestId());
    var tmiDom = document.getElementById(
        'toggle-more-info-' + testResult.getTestId());
    if (miDom.className == 'element-hidden') {
      tmiDom.innerHTML = 'Hide';
      miDom.className = 'element-block';
    } else {
      tmiDom.innerHTML = 'More Information';
      miDom.className = 'element-hidden';
    }
  };

  // Create "More Informaiton" Link
  var toggleShowMoreInformationBtn = document.createElement('div');
  toggleShowMoreInformationBtn.innerHTML = 'More Information';
  toggleShowMoreInformationBtn.id = 'toggle-more-info-' +
      testResult.getTestId();
  toggleShowMoreInformationBtn.className = 'toggle-more-info';
  toggleShowMoreInformationBtn.addEventListener('click',
      toggleShowMoreInformation.bind(this, testResult.getTestId()), false);
  document.getElementById(testResultFrameId).appendChild(
      toggleShowMoreInformationBtn);

  // Create More Information Container
  var moreInfo = document.createElement('div');
  moreInfo.id = 'more-info-container-' + testResult.getTestId();
  moreInfo.className = 'element-hidden';
  document.getElementById(testResultFrameId).appendChild(moreInfo);

  // Create Next Steps Container for Warning and Failing Tests
  if (testResult.getTestVerdict() == ccd.TestVerdict.POTENTIAL_PROBLEM ||
      testResult.getTestVerdict() == ccd.TestVerdict.PROBLEM) {
    var nextStepsContainer = document.createElement('div');
    nextStepsContainer.id = 'next-steps-container';

    var nextStepsTitle = document.createElement('div');
    nextStepsTitle.innerHTML = 'Next Steps';
    nextStepsTitle.className = 'next-steps-title';
    nextStepsContainer.appendChild(nextStepsTitle);

    var nextStepsContents = document.createElement('div');
    nextStepsContents.className = 'next-steps-contents';
    nextStepsContents.innerHTML = testResult.getNextSteps();
    nextStepsContainer.appendChild(nextStepsContents);

    moreInfo.appendChild(nextStepsContainer);
  }

  // Create Container for Logs for Test and Append to More Information
  var logContainer = document.createElement('div');
  logContainer.id = 'log-container-' + testResult.getTestId();
  moreInfo.appendChild(logContainer);

  // Create a label for test logs
  var logsTitle = document.createElement('div');
  logsTitle.innerHTML = 'Test Logs';
  logsTitle.className = 'test-logs-title';
  logContainer.appendChild(logsTitle);

  var logs = document.createElement('textarea');
  logs.readOnly = true;
  logs.cols = 80;
  logs.rows = 10;

  var logStr = 'Test Id: ' + testResult.getTestId() + '\n';
  logStr += 'Test Verdict: ' + testResult.getTestVerdict() + '\n';
  logStr += '\n';

  var testLogs = testResult.getLogs();
  for (var i = 0; i < testLogs.length; i++) {
    logStr += testLogs[i] + '\n';
  }
  logs.value = logStr;

  document.getElementById(logContainer.id).appendChild(logs);
};


/**
 * Populate the results frame, which includes information for tests
 *   that failed, tests that yielded warnings, and provides the
 *   ability to expand and then view results for tests that passed.
 * @param {ccd.TestResults} testResults Results from tests to be populated
 *   into the page.
 * @private
 */
ccd.GuiManager.prototype.fillResultsPage_ = function(testResults) {
  // Show Tests That Failed
  var failedTests =
      testResults.getTestResultsByVerdict(ccd.TestVerdict.PROBLEM);
  for (var i = 0; i < failedTests.length; i++) {
    if (!(failedTests[i] instanceof ccd.TestResult)) continue;
    this.paintTestResult_(failedTests[i]);
  }

  // Show Tests That Warned
  var warningTests =
      testResults.getTestResultsByVerdict(ccd.TestVerdict.POTENTIAL_PROBLEM);
  for (var i = 0; i < warningTests.length; i++) {
    if (!(warningTests[i] instanceof ccd.TestResult)) continue;
    this.paintTestResult_(warningTests[i]);
  }

  // Show Option for Tests That Passed
  var passedTests =
      testResults.getTestResultsByVerdict(ccd.TestVerdict.NO_PROBLEM);
  for (var i = 0; i < passedTests.length; i++) {
    if (!(passedTests[i] instanceof ccd.TestResult)) continue;
    this.paintTestResult_(passedTests[i]);
  }
};


/**
 * The DOM-id of the div that stores the frame for all the test results.
 * @type {string}
 * @private
 */
ccd.GuiManager.prototype.testsResultsFrameId_ = 'results-frame';


/**
 * The DOM-id of the div that stores the frame for passing test results.
 * @type {string}
 * @private
 */
ccd.GuiManager.prototype.testsResultsPassingFrameId_ = 'results-passing-frame';


/**
 * The DOM-id of the div that stores the frame for failing test results.
 * @type {string}
 * @private
 */
ccd.GuiManager.prototype.testsResultsFailingFrameId_ = 'results-failing-frame';


/**
 * The DOM-id of the div that stores the frame for warning test results.
 * @type {string}
 * @private
 */
ccd.GuiManager.prototype.testsResultsWarningFrameId_ = 'results-warning-frame';


/**
 * @type {Spinner}
 * @private
 */
ccd.GuiManager.prototype.spinner_ = null;


/**
 * @type {number}
 * @private
 */
ccd.GuiManager.prototype.testsRunningTimeoutId_ = 0;


/**
 * @type {ccd.TestsManager}
 * @private
 */
ccd.GuiManager.prototype.testsManager_ = null;


/**
 * Setup the DOM for printing out test results.
 * @private
 */
ccd.GuiManager.prototype.setupDomForResults_ = function() {
  // Step 1: Setup Frame to Print out All Results for Tests
  var resultsPageFrame = document.getElementById(this.testsResultsFrameId_);
  if (resultsPageFrame != undefined) {
    // results frame already exists and is probably populated
    // keep the frame present, but clean its contents to prevent
    //   painting duplicate information
    resultsPageFrame.parentNode.removeChild(resultsPageFrame);
  }

  var resultsFrame = document.createElement('div');
  resultsFrame.id = this.testsResultsFrameId_;
  document.getElementById('contents').appendChild(resultsFrame);

  // Step 2: Setup Containers for Failing, Warning, and Passing Tests
  var failingTestsFrame = document.createElement('div');
  failingTestsFrame.id = this.testsResultsFailingFrameId_;
  resultsFrame.appendChild(failingTestsFrame);

  var warningTestsFrame = document.createElement('div');
  warningTestsFrame.id = this.testsResultsWarningFrameId_;
  resultsFrame.appendChild(warningTestsFrame);

  // Step 2b: Create option to toggle whether to show passing tests
  var toggleShowPassingTests = function() {
    var passFrame = document.getElementById(this.testsResultsPassingFrameId_);
    if (passFrame.className == 'element-hidden') {
      document.getElementById('toggle-passing-tests').innerHTML =
          'Hide Tests';
      document.getElementById(this.testsResultsPassingFrameId_).className =
          'element-block';
    } else {
      document.getElementById('toggle-passing-tests').innerHTML =
          'Show Passing Tests';
      document.getElementById(this.testsResultsPassingFrameId_).className =
          'element-hidden';
    }
  };

  var togglePassingTests = document.createElement('div');
  togglePassingTests.id = 'toggle-passing-tests';
  togglePassingTests.className = 'toggle-passing-tests';
  togglePassingTests.innerHTML = 'Show Passing Tests';
  togglePassingTests.addEventListener('click',
      toggleShowPassingTests.bind(this), false);
  resultsFrame.appendChild(togglePassingTests);

  // Step 2c: Setup Containers for Passing Tests
  var passingTestsFrame = document.createElement('div');
  passingTestsFrame.id = this.testsResultsPassingFrameId_;
  passingTestsFrame.className = 'element-hidden';
  resultsFrame.appendChild(passingTestsFrame);
};


/**
 * Callback function invoked to display the results of the tests run.
 * @param {ccd.TestResults} testResults Test results to display onto page.
 */
ccd.GuiManager.prototype.displayResults = function(testResults) {
  window.clearTimeout(this.testsRunningTimeoutId_);

  document.getElementById('page-full-loading-frame').className =
      'page-full-loading-frame-inactive ';
  document.getElementById('page-full-contents').className =
      'page-full-contents-active';
  document.getElementById('page-full-loading-message').innerHTML = '';
  this.spinner_.stopSpinner();

  this.setupDomForResults_();
  this.fillResultsPage_(testResults);
};


/**
 * The tests experienced an unexpected error and need to be stopped.
 * @private
 */
ccd.GuiManager.prototype.handleTestErrors_ = function() {
  window.clearTimeout(this.testsRunningTimeoutId_);
  this.testsManager_.cancelTests();
  this.spinner_.stopSpinner();
  document.getElementById('page-full-loading-message').innerHTML =
      'The tests timed out. Please restart this application and try again.';

  // TODO: Print Logs, Including Logs From Failed Test
};


/**
 * @param {string} message Text to be displayed full-screen to the user.
 */
ccd.GuiManager.prototype.printFullScreenMessage = function(message) {
  document.getElementById('page-full-loading-frame').className =
      'page-full-loading-frame-active';
  document.getElementById('page-full-contents').className =
      'page-full-contents-dimmed';
  document.getElementById('page-full-loading-message').innerHTML = message;
};


/**
 * Start running the series of tests.
 * @private
 */
ccd.GuiManager.prototype.executeTestsSeries_ = function() {
  this.printFullScreenMessage('Tests May Take Up to ' +
      ccd.TestConfVars.TOTAL_TESTS_TIMEOUT_SEC + ' Seconds');

  // set a timeout so that if the tests do not return by a specific time,
  //   the tests stop running
  this.testsRunningTimeoutId_ = setTimeout(this.handleTestErrors_.bind(this),
      1000 * ccd.TestConfVars.TOTAL_TESTS_TIMEOUT_SEC);

  this.spinner_ = new Spinner(250, 250, 20,
                              '#DD4B39', 'page-full-spinner-container');
  this.spinner_.startSpinner();

  var callbackFnc = this.displayResults.bind(this);
  this.testsManager_ = new ccd.TestsManager(callbackFnc);
  this.testsManager_.runTests();
};


/**
 * Run tests to find connectivity problems. When the tests finish,
 *   display the results onto the screen.
 */
ccd.GuiManager.prototype.runTests = function() {
  this.executeTestsSeries_();
};
