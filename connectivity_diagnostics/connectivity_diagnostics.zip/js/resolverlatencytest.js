

/**
 * @fileoverview Test whether there is latency in performing DNS queries.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.ResolverLatencyTest');

goog.require('ccd.Test');
goog.require('ccd.TestConfVars');
goog.require('ccd.TestId');
goog.require('ccd.TestResult');



/**
 * Test the latency of the DNS resolver.
 * @constructor
 * @extends {ccd.Test}
 */
ccd.ResolverLatencyTest = function() {
  goog.base(this);
  this.testResult = new ccd.TestResult(ccd.TestId.RESOLVER_LATENCY);

  /**
   * @private {number}
   */
  this.numTestsCompleted_ = 0;

  /**
   * @private {number}
   */
  this.totalTimeToResolve_ = 0;

  /**
   * @private {number}
   */
  this.testStartMilsec_ = 0;

  /**
   * @private {Array.<string>}
   * @const
   */
  this.hostnamesToQuery_ = ['google.com',
    'mail.google.com',
    'accounts.google.com',
    'facebook.com',
    'yahoo.com',
    'msn.com'];
};
goog.inherits(ccd.ResolverLatencyTest, ccd.Test);


/**
 * The number of milliseconds at which a potential DNS latency problem exists.
 * @private {number}
 * @const
 */
ccd.ResolverLatencyTest.RESOLVER_LATENCY_NO_PROBLEM_MSEC_ = 150;


/**
 * The number of milliseconds at which a potential DNS latency problem exists.
 * @private {number}
 * @const
 */
ccd.ResolverLatencyTest.RESOLVER_LATENCY_POTENTIAL_PROBLEM_MSEC_ = 200;


/**
 * @override
 */
ccd.ResolverLatencyTest.prototype.analyzeResults = function() {
  var avgTime = this.totalTimeToResolve_ / this.hostnamesToQuery_.length;
  this.testResult.addLogRecord('Total DNS resolution time: ' +
      this.totalTimeToResolve_ + 'msec');
  this.testResult.addLogRecord('Total DNS hosts resolved: ' +
      this.hostnamesToQuery_.length);
  this.testResult.addLogRecord('Average DNS resolution time: ' +
      avgTime + 'msec');

  if (avgTime < ccd.ResolverLatencyTest.RESOLVER_LATENCY_NO_PROBLEM_MSEC_) {
    this.testResult.setTitle('No Delay in DNS Resolution');
    this.testResult.setSubtitle('A DNS server translates a hostname ' +
        '(e.g., Google.com) into an IP (e.g., 74.125.228.98). This ' +
        'translating a hostname into an IP is required in order for your ' +
        'browser to connect to the Internet. Chrome is able to quickly ' +
        'resolve DNS requests using your local resolver, which speeds up ' +
        'the process of loading a page.');
    this.testResult.addLogRecord('Average DNS resolution time less than ' +
        ccd.ResolverLatencyTest.RESOLVER_LATENCY_NO_PROBLEM_MSEC_ +
        'milliseconds, no problem detected');
    this.testResult.setTestVerdict(ccd.TestVerdict.NO_PROBLEM);
  } else if (avgTime <
             ccd.ResolverLatencyTest.RESOLVER_LATENCY_POTENTIAL_PROBLEM_MSEC_) {
    this.testResult.setTitle('DNS Resolution Taking Longer Than Average');
    this.testResult.setSubtitle('A DNS server translates a hostname ' +
        '(e.g., Google.com) into an IP (e.g., 74.125.228.98). This ' +
        'translating a hostname into an IP is required in order for your ' +
        'browser to connect to the Internet. The DNS server that performs ' +
        'this translation is taking longer than average, causing some ' +
        'delays in your Internet connection. You can learn more about how ' +
        'to fix this by clicking "More Information".');
    this.testResult.addLogRecord('Average DNS resolution time less than ' +
        ccd.ResolverLatencyTest.RESOLVER_LATENCY_POTENTIAL_PROBLEM_MSEC_ +
        ' milliseconds, potential problem detected');
    this.testResult.setTestVerdict(ccd.TestVerdict.POTENTIAL_PROBLEM);
  } else {
    this.testResult.setTitle('DNS Resolution Taking Too Long');
    this.testResult.setSubtitle('A DNS server translates a hostname ' +
        '(e.g., Google.com) into an IP (e.g., 74.125.228.98). This ' +
        'translating a hostname into an IP is required in order for your ' +
        'browser to connect to the Internet. The DNS server that performs ' +
        'this translation is taking too long, causing delays in your ' +
        'Internet connection. You can learn more about how to fix this ' +
        'by clicking "More Information".');
    this.testResult.addLogRecord('Average DNS resolution time greater than ' +
        ccd.ResolverLatencyTest.RESOLVER_LATENCY_POTENTIAL_PROBLEM_MSEC_ +
        'milliseconds, problem detected');
    this.testResult.setTestVerdict(ccd.TestVerdict.PROBLEM);
  }
};


/**
 * Process a DNS query response.
 * See #chromium/src/chrome/common/extensions/api/experimental_dns.idl
 * @param {chrome.experimental.dns.ResolveCallbackResolveInfo} resultInfo
 *   DNS query result info.
 * @private
 */
ccd.ResolverLatencyTest.prototype.resolvedCallback_ = function(resultInfo) {
  var currMilliseconds = (new Date).getTime();
  var millisecondsTaken = currMilliseconds - this.testStartMilsec_;
  this.totalTimeToResolve_ += millisecondsTaken;
  this.testResult.addLogRecord('Result received for resolution of hostname ' +
      this.numTestsCompleted_ + ' at ' + currMilliseconds + ', which took ' +
      millisecondsTaken + 'msec and began at ' + this.testStartMilsec_);

  this.numTestsCompleted_++;
  window.clearTimeout(this.timeoutId_);
  if (this.numTestsCompleted_ < this.hostnamesToQuery_.length) {
    // Allow code to be run synchronously to make testing easier.
    if (ccd.TestConfVars.RESOLVER_LATENCY_SLEEP_MILSEC > 0) {
      this.timeoutId_ = window.setTimeout(this.resolveHostname_.bind(this),
          ccd.TestConfVars.RESOLVER_LATENCY_SLEEP_MILSEC);
    } else {
      this.resolveHostname_();
    }
  } else {
    this.analyzeResults();
    this.executeCallback();
  }
};


/**
 * Make a DNS request.
 * @private
 */
ccd.ResolverLatencyTest.prototype.resolveHostname_ = function() {
  var hostname = this.hostnamesToQuery_[this.numTestsCompleted_];

  this.testStartMilsec_ = (new Date).getTime();
  this.testResult.addLogRecord('Attempting to resolve hostname ' +
      this.numTestsCompleted_ + ': ' + hostname + ' at time ' +
      this.testStartMilsec_);
  chrome.experimental.dns.resolve(hostname,
                                  this.resolvedCallback_.bind(this));
};


/**
 * @override
 */
ccd.ResolverLatencyTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;
  this.resolveHostname_();
};
