

/**
 * @fileoverview Test whether ChromeOS has a network connection.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.ConnectionPresentTest');

goog.require('ccd.Test');
goog.require('ccd.TestId');
goog.require('ccd.TestResult');
goog.require('ccd.TestVerdict');



/**
 * Test whether ChromeOS has a network connection.
 * @constructor
 * @extends {ccd.Test}
 */
ccd.ConnectionPresentTest = function() {
  goog.base(this);
  this.testResult = new ccd.TestResult(ccd.TestId.NIC_CONNECTION_PRESENT);
};
goog.inherits(ccd.ConnectionPresentTest, ccd.Test);


/**
 * @param {Array.<chrome.networkingPrivate.NetworkProperties>} netData Data on networks.
 */
ccd.ConnectionPresentTest.prototype.processNetworkData_ = function(netData) {

};


/**
 * @override
 */
ccd.ConnectionPresentTest.prototype.analyzeResults = function() {

};


/**
 * @override
 */
ccd.ResolverPresentTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;

  this.testResult.addLogRecord('About to begin searching for available ' +
      'networks ');

  chrome.networkingPrivate.getVisibleNetworks("All", );
};
