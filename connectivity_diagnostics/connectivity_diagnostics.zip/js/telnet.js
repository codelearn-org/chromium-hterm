// Copyright Google 2013. All Rights Reserved.


/**
 * @fileoverview Model a basic Telnet client to send/receive TCP commuincations
 *               and test whether there is a firewall.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.Telnet');

goog.require('ccd.TestConfVars');



/**
 * Open a TCP connection with a specific host on a specific port.
 * @param {string} host Hostname to open a connection with.
 * @param {number} port Port number to connect on.
 * @param {ccd.TestResult} testResult Manage output logs.
 * @constructor
 */
ccd.Telnet = function(host, port, testResult) {
  this.host_ = host;
  this.port_ = port;
  this.testResult_ = testResult;
};


/**
 * @type {number}
 * @private
 */
ccd.Telnet.prototype.socketTimeout_ =
    ccd.TestConfVars.TCP_SOCKET_TIMEOUT_MILSEC;


/**
 * @type {number}
 * @private
 */
ccd.Telnet.prototype.timeoutId_ = 0;


/**
 * Hostname to connect to.
 * @type {string}
 * @private
 */
ccd.Telnet.prototype.host_ = '';


/**
 * Port to connect on.
 * @type {number}
 * @private
 */
ccd.Telnet.prototype.port_ = -1;


/**
 * ID of socket used to connect to host.
 * @type {number}
 * @private
 */
ccd.Telnet.prototype.socketId_ = -1;


/**
 * ArrayBuffer of binary data to send to destination host.
 * @type {ArrayBuffer}
 * @private
 */
ccd.Telnet.prototype.abDataToSend_ = null;


/**
 * ASCII text to send.
 * @type {string}
 * @private
 */
ccd.Telnet.prototype.strDataToSend_ = '';


/**
 * Test result to store logs from test.
 * @type {ccd.TestResult}
 * @private
 */
ccd.Telnet.prototype.testResult_ = null;


/**
 * Function to callback upon completion of the telnet session.
 * @type {?function(ccd.Telnet.TcpConnStatus)}
 * @private
 */
ccd.Telnet.prototype.completedCallbackFnc_ = null;


/**
 * Function to callback upon failure of the telnet session.
 * @type {?function(ccd.Telnet.TcpConnStatus)}
 * @private
 */
ccd.Telnet.prototype.failureCallbackFnc_ = null;


/**
 * Function to callback upon connection status being known, either failure
 *   or success.
 * @type {?function(number)}
 * @private
 */
ccd.Telnet.prototype.connectionStatusKnownCallbackFnc_ = null;


/**
 * @see http://src.chromium.org/svn/trunk/src/net/base/net_error_list.h
 * @enum {number}
 */
ccd.Telnet.TcpConnStatus = {
  // TCP connection established successfully
  SUCCESS: 0,

  // Connection failed to establish in some form
  CONNECTION_FAILURE: -1,

  // A connection attempt timed out.
  CONNECTION_TIMED_OUT: -118,

  // The host name could not be resolved.
  NAME_NOT_RESOLVED: -105,

  // A connection attempt was refused.
  CONNECTION_REFUSED: -102
};


/**
 * Set function to be called when telnet is finished.
 * @param {function(ccd.Telnet.TcpConnStatus)} fnc Function to call upon
 *                                                   completion of telnet
 *                                                   session.
 */
ccd.Telnet.prototype.setCompletedCallbackFnc = function(fnc) {
  this.completedCallbackFnc_ = fnc;
};


/**
 * Set function to be called if connection fails to be established.
 * @param {function(ccd.Telnet.TcpConnStatus)} fnc Function to call upon
 *                                                   failure of telnet
 *                                                   session.
 */
ccd.Telnet.prototype.setFailureCallbackFnc = function(fnc) {
  this.failureCallbackFnc_ = fnc;
};


/**
 * Set function to be called when telnet connection status is established.
 * This function will be triggered as soon as the connection status is known,
 *   either success or some type of failure.
 * @param {function(number)} fnc Function to call upon
 *   knowing the status of a TCP connection.
 */
ccd.Telnet.prototype.setConnectionStatusKnownCallbackFnc = function(fnc) {
  this.connectionStatusKnownCallbackFnc_ = fnc;
};


/**
 * Set the text to send to the host.
 * @param {string} textToSend Text to send to the host.
 */
ccd.Telnet.prototype.setPlainTextDataToSend = function(textToSend) {
  this.strDataToSend_ = textToSend;
};


/**
 * Attempt to open the TCP connection and send the data passed thus far.
 */
ccd.Telnet.prototype.startConnection = function() {
  this.createSocket_();
};


/**
  * Converts an array buffer to a string.
  * @param {ArrayBuffer} buf The buffer to convert.
  * @param {Function} callback The function to call when conversion is complete.
  * @private
  */
ccd.Telnet.prototype.arrayBufferToString_ = function(buf, callback) {
  var bb = new Blob([new Uint8Array(buf)]);
  var f = new FileReader();
  f.onload = function(e) {
    callback(e.target.result);
  };
  f.readAsText(bb);
};


/**
 * Converts a string to an array buffer.
 * @param {string} str The string to convert.
 * @param {Function} callback The function to call when conversion is complete.
 * @private
 */
ccd.Telnet.prototype.stringToArrayBuffer_ = function(str, callback) {
  var bb = new Blob([str]);
  var f = new FileReader();
  f.onload = function(e) {
    callback(e.target.result);
  };
  f.readAsArrayBuffer(bb);
};


/**
 * Process the data read over the socket.
 * @param {chrome.socket.ReadInfo} readInfo Data read from the socket.
 * @see http://developer.chrome.com/apps/socket.html#type-ReadInfo
 * @private
 */
ccd.Telnet.prototype.onReadCompletedCallback_ = function(readInfo) {
  /**
   * Receive string response from host.
   * @param {string} str Text received from destination host.
   * @this {ccd.Telnet}
   */
  function receiveString_(str) {
    this.testResult_.addLogRecord('Received ' + str);
    this.closeSocket_();
    this.completedCallbackFnc_(ccd.Telnet.TcpConnStatus.SUCCESS);
  }

  if (readInfo.resultCode > 0) {
    this.testResult_.addLogRecord('Successfully read ' + readInfo.resultCode +
        ' bytes of data');
    this.arrayBufferToString_(readInfo.data, receiveString_.bind(this));
  } else {
    this.testResult_.addLogRecord('Error reading data. Code ' +
        readInfo.resultCode);
  }
};


/**
 * Read data from the TCP socket.
 * @private
 */
ccd.Telnet.prototype.read_ = function() {
  chrome.socket.read(this.socketId_, this.onReadCompletedCallback_.bind(this));
};


/**
 * Function to call upon completing the writing of data.
 * @param {chrome.socket.WriteInfo} writeInfo Information about data
 *   written to host.
 * @see http://developer.chrome.com/apps/socket.html#type-WriteInfo
 * @private
 */
ccd.Telnet.prototype.onWriteCompleteCallback_ = function(writeInfo) {
  this.testResult_.addLogRecord('Successfully sent ' + writeInfo.bytesWritten +
      ' bytes of data');
  this.read_();
};


/**
 * Write binary data to destination host.
 * @private
 */
ccd.Telnet.prototype.write_ = function() {
  this.testResult_.addLogRecord('Prepared to send ' +
      this.abDataToSend_.byteLength + ' bytes of data');

  chrome.socket.write(this.socketId_,
                      this.abDataToSend_,
                      this.onWriteCompleteCallback_.bind(this));
};


/**
 * Process socket information upon successful TCP connection with host.
 * ResultStatus is the network code specified in
 *   #chromium/src/net/base/net_error_list.h
 * @param {number} resultStatus Status code for TCP connection.
 * @private
 */
ccd.Telnet.prototype.onConnectedCallback_ = function(resultStatus) {
  if (this.connectionStatusKnownCallbackFnc_ != null) {
    this.testResult_.addLogRecord('TCP connection with ' + this.host_ +
        ' on port ' + this.port_ + ' returned status code: ' + resultStatus);
    this.closeSocket_();
    this.connectionStatusKnownCallbackFnc_(resultStatus);

    // need return to prevent this function from keeping on executing
    // TODO: Try to understand callback flow for why this return is necessary
    //   when we are calling out into another function that should break this
    return;
  }

  if (resultStatus == ccd.Telnet.TcpConnStatus.CONNECTION_FAILURE) {
    this.testResult_.addLogRecord('TCP connection with ' + this.host_ +
        ' on port ' + this.port_ + ' failed to establish; ' +
        'general connection failure');
    this.closeSocket_();
    this.failureCallbackFnc_(ccd.Telnet.TcpConnStatus.CONNECTION_FAILURE);
    return;
  } else if (resultStatus == ccd.Telnet.TcpConnStatus.CONNECTION_TIMED_OUT) {
    this.testResult_.addLogRecord('TCP connection with ' + this.host_ +
        ' on port ' + this.port_ + ' failed to establish; connection timeout');
    this.closeSocket_();
    this.failureCallbackFnc_(ccd.Telnet.TcpConnStatus.CONNECTION_TIMED_OUT);
    return;
  } else if (resultStatus == ccd.Telnet.TcpConnStatus.CONNECTION_REFUSED) {
    this.testResult_.addLogRecord('TCP connection with ' + this.host_ +
        ' on port ' + this.port_ + ' failed to establish; connection refused');
    this.closeSocket_();
    this.failureCallbackFnc_(ccd.Telnet.TcpConnStatus.CONNECTION_REFUSED);
    return;
  }

  this.testResult_.addLogRecord('TCP connection with ' + this.host_ +
      ' on port ' + this.port_ + ' established');

  /**
   * Receive converted ArrayBuffer.
   * @param {ArrayBuffer} ab ArrayBuffer of information to send.
   * @this {ccd.Telnet}
   */
  function receiveArrBuffer(ab) {
    this.abDataToSend_ = ab;

    //socket open, data converted to binary, ready to send it
    this.write_();
  }

  this.stringToArrayBuffer_(this.strDataToSend_, receiveArrBuffer.bind(this));
};


/**
 * Create a TCP socket.
 * @private
 */
ccd.Telnet.prototype.createSocket_ = function() {
  /**
   * Process created socket information.
   * @param {chrome.socket.CreateInfo} createInfo Info on created socket.
   * @this {ccd.Telnet}
   * @see http://developer.chrome.com/apps/socket.html#type-CreateInfo
   * @private
   */
  function onCreated_(createInfo) {
    this.socketId_ = createInfo.socketId;
    this.testResult_.addLogRecord('TCP socket #' + this.socketId_ +
        ' created.');
    this.testResult_.addLogRecord('About to connect TCP socket #' +
        this.socketId_ + ' to host ' + this.host_ + ' on port ' + this.port_);
    chrome.socket.connect(this.socketId_,
                          this.host_,
                          this.port_,
                          this.onConnectedCallback_.bind(this));
  }

  // set a timeout that is lower than the native TCP timeout
  this.testResult_.addLogRecord('Setting TCP timeout to ' +
      this.socketTimeout_ + 'sec');
  this.timeoutId_ = window.setTimeout(this.timeoutCallback_.bind(this),
                                      this.socketTimeout_);

  this.testResult_.addLogRecord('About to create TCP socket');
  chrome.socket.create('tcp', {}, onCreated_.bind(this));
};


/**
 * Close TCP socket.
 * @private
 */
ccd.Telnet.prototype.closeSocket_ = function() {
  chrome.socket.disconnect(this.socketId_);
  chrome.socket.destroy(this.socketId_);
  window.clearTimeout(this.timeoutId_);
};


/**
 * @private
 */
ccd.Telnet.prototype.timeoutCallback_ = function() {
  if (this.connectionStatusKnownCallbackFnc_ != null) {
    this.closeSocket_();
    this.connectionStatusKnownCallbackFnc_(
        ccd.Telnet.TcpConnStatus.CONNECTION_TIMED_OUT);
  }
};
