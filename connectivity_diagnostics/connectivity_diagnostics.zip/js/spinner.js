// Copyright 2013 Google Inc. All Rights Reserved.


/**
 * @fileoverview Provide a spinner.
 * @author ebeach@google.com (Eric Beach)
 * Based in part off http://blogs.adobe.com/cantrell/archives/2011/12/
 *   creating-a-loading-spinner-animation-in-css-and-javascript.html
 */


goog.provide('Spinner');



/**
 * @param {number} width The width of the spinner.
 * @param {number} height The height of the spinner.
 * @param {number} numBars The number of bars in the spinner.
 * @param {string} color The color of the spinner.
 * @param {string} domContainerId The ID of the spinner.
 * @constructor
 */
Spinner = function(width, height, numBars, color, domContainerId) {
  this.width_ = width;
  this.height_ = height;
  this.numBars_ = numBars;
  this.color_ = color;
  this.domContainerId_ = domContainerId;
};


/**
 * @type {boolean}
 * @private
 */
Spinner.prototype.isRunning_ = false;


/**
 * @type {string}
 * @private
 */
Spinner.prototype.domContainerId_ = '';


/**
 * @type {number}
 * @private
 */
Spinner.prototype.width_ = 0;


/**
 * @type {number}
 * @private
 */
Spinner.prototype.height_ = 0;


/**
 * @type {number}
 * @private
 */
Spinner.prototype.numBars_ = 0;


/**
 * (e.g., "#DD4B39" or "#eee")
 * @type {string}
 * @private
 */
Spinner.prototype.color_ = '';


/**
 * @type {string}
 * @private
 */
Spinner.prototype.prefix_ = 'webkit';


/**
 * Generate a DOM element with a spinner inside it and return the DOM element.
 * @return {Element} DOM element with a spinner inside.
 * @private
 */
Spinner.prototype.generateSpinnerElement_ = function() {
  // test whether a spinner is already hidden in the DOM
  // if so, remove it so a new spinner can be created
  var innerContainer = document.getElementById('spinner-inner-container');
  if (innerContainer != undefined) {
    innerContainer.parentNode.removeChild(innerContainer);
  }

  var spinner = document.createElement('div');
  spinner.id = 'spinner-inner-container';
  spinner.style.width = this.width_ + 'px';
  spinner.style.height = this.height_ + 'px';
  spinner.style.position = 'relative';
  spinner.style.setProperty('margin', '0 auto', '');
  spinner.style.setProperty('opacity', '1', '');

  var rotation = 0;
  var rotateBy = 360 / this.numBars_;
  var animationDelay = 0;
  var frameRate = 1 / this.numBars_;
  for (var i = 0; i < this.numBars_; ++i) {
    var bar = document.createElement('div');
    spinner.appendChild(bar);
    bar.style.width = '4%';
    bar.style.height = '20%';
    bar.style.background = this.color_;
    bar.style.position = 'absolute';
    bar.style.left = '44.5%';
    bar.style.top = '37%';
    bar.style.opacity = '1';
    bar.style.setProperty('border-radius', '150px', '');
    bar.style.setProperty('-' + this.prefix_ + '-animation',
                          'fade 1s linear infinite', '');
    bar.style.setProperty('-' + this.prefix_ + '-transform',
                          'rotate(' + rotation + 'deg) translate(0, -142%)',
                          '');
    bar.style.setProperty('-' + this.prefix_ + '-animation-delay',
                          animationDelay + 's', '');
    rotation += rotateBy;
    animationDelay -= frameRate;
  }
  return spinner;
};


/**
 * Start the spinner by generating it and then appending it as a child
 *   to the container element.
 */
Spinner.prototype.startSpinner = function() {
  var spinner = this.generateSpinnerElement_();
  document.getElementById(this.domContainerId_).appendChild(spinner);
  this.isRunning_ = true;
};


/**
 * Stop the spinner by removing the spinner from the container DOM element.
 */
Spinner.prototype.stopSpinner = function() {
  var containerDom = document.getElementById(this.domContainerId_);
  if (containerDom != undefined) {
    containerDom.removeChild(containerDom.firstChild);
  }
  this.isRunning_ = false;
};


/**
 * @return {boolean} Whether the spinner is currently running.
 */
Spinner.prototype.getIsRunning = function() {
  return this.isRunning_;
};
