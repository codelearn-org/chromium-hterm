

/**
 * @fileoverview Store configuration variables for tests.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.TestConfVars');


/**
 * Enum to store various configuration variables for tests.
 * @enum {number}
 */
ccd.TestConfVars = {
  // TODO(ebeach): reset this to be the number of random hosts to query
  // always query the array of Google hosts, but add in X random hosts
  NUM_HOSTS_CAPTIVE_PORTAL_DNS_TEST: 5,

  CAPTIVE_PORTAL_DNS_SLEEP_MILSEC: 1000,

  XHR_TIMEOUT_MILSEC: 7000,

  RESOLVER_LATENCY_SLEEP_MILSEC: 1000,

  TOTAL_TESTS_TIMEOUT_SEC: 120,

  TCP_SOCKET_TIMEOUT_MILSEC: 3000,

  XHR_SLEEP_MILSEC: 2000,

  FIREWALL_TCP_REQUEST_TIMEOUT_MILSEC: 1000,

  // Maximum number of times a user can click "Run Tests" per session
  MAX_TEST_RUNS_PER_SESSION: 2
};
