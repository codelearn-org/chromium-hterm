// Copyright 2013 Google Inc. All Rights Reserved.


/**
 * @fileoverview Bootstrap the management of the GUI.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd');
goog.provide('ccd.Bootstrap');

goog.require('ccd.Launcher');



/**
 * Bootstrap the network debugger app.
 *
 * @constructor
 */
ccd.Bootstrap = function() {
  this.addDomEventListeners();
};


/**
 * Add event listeners to the DOM to handle the launch button click.
 */
ccd.Bootstrap.prototype.addDomEventListeners = function() {
  document.getElementById('launch-tests-btn').addEventListener('click',
      ccd.Launcher.LaunchTestsGui, false);
};

goog.exportSymbol('ChromeConnectivityDebugger', ccd.Bootstrap);
