

/**
 * @fileoverview  Enum to represent tests.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.TestId');


/**
 * Enum to store the unique identifier for each specific test that
 *   can be run.
 * @enum {number}
 */
ccd.TestId = {
  CHROME_VERSION: 0,
  CHROMEOS_VERSION: 1,
  DNS_RESOLVER_PRESENT: 2,
  CAPTIVE_PORTAL_DNS: 3,
  CAPTIVE_PORTAL_HTTP: 4,
  FIREWALL_80: 5,
  FIREWALL_443: 6,
  RESOLVER_LATENCY: 7,
  HTTP_LATENCY: 8,
  DNS_RESOLVER_LOCAL_POISONING: 9,
  DNS_RESOLVER_PUBLIC_POISONING: 10,
  NIC_NETWORK_AVAILABLE: 11,
  NIC_CONNECTION_PRESENT: 12,
  NIC_SIGNAL_STRENGTH: 13
};
