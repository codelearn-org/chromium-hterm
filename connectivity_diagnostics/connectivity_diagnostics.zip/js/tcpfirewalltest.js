// Copyright 2013 Google Inc. All Rights Reserved.


/**
 * @fileoverview Test whether firewall is blocking a specific TCP port.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.TcpFirewallTest');

goog.require('ccd.Telnet');
goog.require('ccd.Test');
goog.require('ccd.TestId');
goog.require('ccd.TestResult');
goog.require('ccd.TestVerdict');



/**
 * Test for a firewall on a specific port.
 * @param {number} port TCP port number to test.
 * @param {ccd.TestId} testId Test ID.
 * @constructor
 * @extends {ccd.Test}
 */
ccd.TcpFirewallTest = function(port, testId) {
  goog.base(this);
  this.testResult = new ccd.TestResult(testId);
  this.numTestsCompleted_ = 0;
  this.portToTest_ = port;
  this.testId_ = testId;
  this.connectionStatusCodes_ = new Array();
};
goog.inherits(ccd.TcpFirewallTest, ccd.Test);


/**
 * Test ID being executed.
 * @type {?ccd.TestId}
 * @private
 */
ccd.TcpFirewallTest.prototype.testId_ = null;


/**
 * @type {Array.<number>}
 * @private
 */
ccd.TcpFirewallTest.prototype.connectionStatusCodes_ = null;


/**
 * @type {number}
 * @private
 */
ccd.TcpFirewallTest.prototype.portToTest_ = 0;


/**
 * @type {number}
 * @private
 */
ccd.TcpFirewallTest.prototype.numTestsCompleted_ = 0;


/**
 * Array of hostnames to test.
 * @type {Array.<string>}
 * @private
 */
ccd.TcpFirewallTest.prototype.hostnamesToTest_ = ['www.google.com',
                                                  'mail.google.com',
                                                  'drive.google.com',
                                                  'accounts.google.com',
                                                  'www.gstatic.com',
                                                  'facebook.com',
                                                  'mail.yahoo.com'];


/**
 * @type {number}
 * @private
 */
ccd.TcpFirewallTest.prototype.timeoutId_ = 0;


/**
 * Analyze test results.
 */
ccd.TcpFirewallTest.prototype.analyzeResults = function() {
  var numFailedConnections = 0;
  for (var i = 0; i < this.hostnamesToTest_.length; i++) {
    if (this.connectionStatusCodes_[i] !== 0) {
      this.testResult.addLogRecord('Connection attempt #' + i +
          ' failed and did not return TCP ' +
          'status code 0 from the network stack');
      numFailedConnections++;
    }
  }

  if (numFailedConnections == 0) {
    // verdict success (no firewall)
    this.testResult.setTestVerdict(ccd.TestVerdict.NO_PROBLEM);
    this.testResult.setTitle('Internet Traffic Not Blocked by Firewall ' +
        '(Port ' + this.portToTest_ + ')');
    this.testResult.setSubtitle('A firewall prevents an Internet connection ' +
        'from being established from your machine to any other computer ' +
        'server. No firewall was detected on port ' + this.portToTest_ +
        ' (which is the port that the Internet uses).');
    this.testResult.addLogRecord('Firewall test found no problems on port ' +
        this.portToTest_ + '. Verdict: no problem detected.');
  } else if (numFailedConnections == this.hostnamesToTest_.length) {
    // firewall
    this.testResult.setTestVerdict(ccd.TestVerdict.PROBLEM);
    this.testResult.setTitle('Internet Traffic Blocked by Firewall ' +
        '(Port 80)');
    this.testResult.setSubtitle('A firewall prevents an Internet connection ' +
        'from being established from your machine to any other computer ' +
        'server. A firewall on port ' + this.portToTest_ +
        ' (which is the port that the Internet uses) was detected. ' +
        'This means your computer cannot connect to Internet websites. ' +
        'You can learn more about how to fix this by clicking ' +
        '"More Information".');
    this.testResult.addLogRecord('Firewall test failed for each hostname ' +
        'tested on port ' + this.portToTest_ + '. Verdict: Problem detected.');
  } else {
    // probable firewall
    this.testResult.setTestVerdict(ccd.TestVerdict.POTENTIAL_PROBLEM);
    this.testResult.setTitle('Internet Traffic May Be Blocked by Firewall ' +
        '(Port ' + this.portToTest_ + ')');
    this.testResult.addLogRecord('Firewall test failed for some hostnames ' +
        'tested on port ' + this.portToTest_ + '. Verdict: potential ' +
        'problem detected.');
  }

  this.testResult.addLogRecord('Firewall test completed. Tested ' +
      this.numTestsCompleted_ + ' hostnames on port ' + this.portToTest_ +
      ' and found ' + numFailedConnections + ' failed connections.');
};


/**
 * @param {function(this:ccd.TestsManager, ccd.TestResult)} callbackFnc
 *   Function to execute upon completion of test.
 */
ccd.TcpFirewallTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;
  this.attemptConnection_();
};


/**
 * @param {number} respStatus Statuc of the
 *   TCP connection. See also #chromium/src/net/base/net_error_list.h.
 * @private
 */
ccd.TcpFirewallTest.prototype.connectionStatusKnown_ = function(respStatus) {
  this.testResult.addLogRecord('Test# ' + this.numTestsCompleted_ +
      ' Returned TCP Status Code: ' + respStatus);

  this.connectionStatusCodes_[this.numTestsCompleted_] = respStatus;

  this.numTestsCompleted_++;
  if (this.numTestsCompleted_ < this.hostnamesToTest_.length) {
    this.timeoutId_ = window.setTimeout(this.attemptConnection_.bind(this),
        ccd.TestConfVars.FIREWALL_TCP_REQUEST_TIMEOUT_MILSEC);
  } else {
    this.analyzeResults();
    this.executeCallback();
  }
};


/**
 * @private
 */
ccd.TcpFirewallTest.prototype.attemptConnection_ = function() {
  var hostname = this.hostnamesToTest_[this.numTestsCompleted_];
  this.testResult.addLogRecord('About to attempt TCP connection # ' +
      this.numTestsCompleted_ + ' to hostname: ' + hostname +
      ' on port ' + this.portToTest_);

  var telnet = new ccd.Telnet(hostname,
                              this.portToTest_,
                              this.testResult);

  telnet.setConnectionStatusKnownCallbackFnc(
      this.connectionStatusKnown_.bind(this));
  telnet.setPlainTextDataToSend('GET / HTTP/1.1');
  telnet.startConnection();
};


/**
 * Tests completed, execute the callback.
 */
ccd.TcpFirewallTest.prototype.executeCallback = function() {
  window.clearTimeout(this.timeoutId_);
  this.callbackFnc(this.testResult);
};
