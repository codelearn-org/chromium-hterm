// Copyright 2013 Google Inc. All Rights Reserved.


/**
 * @fileoverview Test the latency of HTTP requests.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.HttpLatencyTest');

goog.require('ccd.HostType');
goog.require('ccd.Test');
goog.require('ccd.TestId');
goog.require('ccd.TestVerdict');



/**
 * @constructor
 * @extends {ccd.Test}
 */
ccd.HttpLatencyTest = function() {
  goog.base(this);
  this.testResult = new ccd.TestResult(ccd.TestId.HTTP_LATENCY);
  this.numTestsCompleted_ = 0;
  this.totalTimeToRespond_ = 0;
  this.xhr_ = new Array();
};
goog.inherits(ccd.HttpLatencyTest, ccd.Test);


/**
 * @type {number}
 * @private
 */
ccd.HttpLatencyTest.prototype.numTestsCompleted_ = 0;


/**
 * @type {Array.<XMLHttpRequest>}
 * @private
 */
ccd.HttpLatencyTest.prototype.xhr_ = null;


/**
 * @type {number}
 * @private
 */
ccd.HttpLatencyTest.prototype.timeoutId_ = 0;


/**
 * @type {number}
 * @private
 */
ccd.HttpLatencyTest.prototype.totalTimeToRespond_ = 0;


/**
 * @type {Array.<ccd.HostType, string>}
 * @private
 */
ccd.HttpLatencyTest.prototype.hostnamesToQuery_ = [
  [ccd.HostType.GOOGLE, 'www.google.com/generate_204'],

  // TODO: mysteriously doesn't work
  //[ccd.HostType.GOOGLE, 'mail.google.com/generate_204'],

  [ccd.HostType.GOOGLE, 'mail.google.com/generate_204']
];


/**
 * Execute the callback function to be run upon completion of the test.
 */
ccd.HttpLatencyTest.prototype.executeCallback = function() {
  window.clearTimeout(this.timeoutId_);
  this.callbackFnc(this.testResult);
};


/**
 * Analyze the HTTP requests to search for latency.
 */
ccd.HttpLatencyTest.prototype.analyzeResults = function() {
  var avgTime = this.totalTimeToRespond_ / this.hostnamesToQuery_.length;
  this.testResult.addLogRecord('Total HTTP response time: ' +
      this.totalTimeToRespond_);
  this.testResult.addLogRecord('Total HTTP requests: ' +
      this.hostnamesToQuery_.length);
  this.testResult.addLogRecord('Average HTTP response time: ' + avgTime);

  if (avgTime < 75) {
    this.testResult.setTitle('No Delays in Receiving Responses from Websites');
    this.testResult.setSubtitle('Web requests being received quickly.');
    this.testResult.addLogRecord('Average HTTP latency time less than 75 ' +
        'milliseconds, no problem detected');
    this.testResult.setTestVerdict(ccd.TestVerdict.NO_PROBLEM);
  } else if (avgTime < 100) {
    this.testResult.setTitle('Web Requests Taking Longer Than Normal');
    this.testResult.setSubtitle('It is taking a little longer than it ' +
        'should to receive a response from websites, indicating there is a ' +
        'slow network. You can learn more about this as well as how to fix ' +
        'this by clicking "More Information".');
    this.testResult.addLogRecord('Average HTTP latency time less than 100 ' +
        'milliseconds, potential problem detected');
    this.testResult.setTestVerdict(ccd.TestVerdict.POTENTIAL_PROBLEM);
  } else {
    this.testResult.setTitle('Web Requests Taking too Long');
    this.testResult.setSubtitle('It is taking longer than it should to ' +
        'receive a response from websites, indicating there is a slow ' +
        'network. You can learn more about how to fix this by clicking ' +
        '"More Information".');
    this.testResult.addLogRecord('Average HTTP latency time greater than 100 ' +
        'seconds, problem detected');
    this.testResult.setTestVerdict(ccd.TestVerdict.PROBLEM);
  }
};


/**
 * @param {number} requestNum HTTP request number in test series.
 * @param {number} startMilliseconds Microtimestamp the HTTP request began.
 * @private
 */
ccd.HttpLatencyTest.prototype.responseReceived_ = function(requestNum,
                                                           startMilliseconds) {
  var currMilliseconds = (new Date).getTime();
  var millisecondsTaken = currMilliseconds - startMilliseconds;
  this.totalTimeToRespond_ += millisecondsTaken;

  this.testResult.addLogRecord('Received HTTP response for request #' +
      requestNum);

  this.testResult.addLogRecord('Response #' + requestNum + ' received at ' +
      currMilliseconds + ', which took a total of ' + millisecondsTaken);

  this.numTestsCompleted_ = requestNum + 1;
  window.clearTimeout(this.timeoutId_);
  if (this.numTestsCompleted_ < this.hostnamesToQuery_.length) {
    this.timeoutId_ = setTimeout(this.requestHostname_.bind(this),
                                 ccd.TestConfVars.XHR_SLEEP_MILSEC);
  } else {
    this.analyzeResults();
    this.executeCallback();
  }
};


/**
 * @param {number} requestNum HTTP request number in test series.
 * @param {ajax.XMLHttpRequestProgressEvent} progressEvent AJAX error object.
 * @private
 */
ccd.HttpLatencyTest.prototype.requestError_ = function(requestNum,
                                                       progressEvent) {
  // TODO: need better way to handle this error, which signals a test
  //   problem; maybe execute callback with warning verdict
  this.totalTimeToRespond_ += 10000;
  this.testResult.addLogRecord('Error occurred in XHR request # ' + requestNum);
  this.testResult.addLogRecord('XHR readyState in error request: ' +
      this.xhr_[requestNum].readyState);
};


/**
 * Make an HTTP request, whose response time it clocked.
 * @private
 */
ccd.HttpLatencyTest.prototype.requestHostname_ = function() {
  var requestNum = this.numTestsCompleted_;
  this.xhr_[requestNum] = new XMLHttpRequest();

  this.xhr_[requestNum].onabort = this.requestError_.bind(this, requestNum);
  this.xhr_[requestNum].onerror = this.requestError_.bind(this, requestNum);
  this.xhr_[requestNum].timeout = ccd.TestConfVars.XHR_TIMEOUT_MILSEC;

  // setup function to handle successful response
  var readyStateChange = function() {
    if ((this.xhr_[requestNum].readyState < 4)) return;

    this.testResult.addLogRecord('Received successful XHR response for ' +
        'request ' + requestNum);
    var boundFnc = this.responseReceived_.bind(this,
                                               requestNum,
                                               startMilliseconds);
    boundFnc();
  };
  this.xhr_[requestNum].onreadystatechange = readyStateChange.bind(this);

  var startMilliseconds = (new Date).getTime();
  var hostname = 'http://' + this.hostnamesToQuery_[requestNum][1];
  this.testResult.addLogRecord('About to issue XHR request # ' + requestNum +
      ' to: ' + hostname + ' at time ' + startMilliseconds);
  this.xhr_[requestNum].open('GET', hostname);
  this.xhr_[requestNum].send();
};


/**
 * @param {function(this:ccd.TestsManager, ccd.TestResult)} callbackFnc
 *   Function to execute upon completion of test.
 */
ccd.HttpLatencyTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;
  this.requestHostname_();
};
