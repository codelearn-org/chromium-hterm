// Copyright 2013 Google Inc. All Rights Reserved.

/**
 * @fileoverview  Launch the connectivity tests GUI.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.Launcher');

goog.require('ccd.GuiManager');


/**
 * @type {number}
 * @private
 */
ccd.Launcher.numTestsSeriesLaunched_ = 0;


/**
 * Launch the test GUI.
 */
ccd.Launcher.LaunchTestsGui = function() {
  var guiManager = new ccd.GuiManager();
  if (ccd.Launcher.numTestsSeriesLaunched_ >=
      ccd.TestConfVars.MAX_TEST_RUNS_PER_SESSION) {
    guiManager.printFullScreenMessage('For security reasons, you can only ' +
        'run the tests ' + ccd.TestConfVars.MAX_TEST_RUNS_PER_SESSION +
        ' times per session. If you need to run the tests again, ' +
        'please quit the App and re-launch.');
  } else {
    ccd.Launcher.numTestsSeriesLaunched_++;
    guiManager.runTests();
  }
};

