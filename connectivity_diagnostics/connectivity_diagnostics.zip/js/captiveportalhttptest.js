// Copyright 2013 Google Inc. All Rights Reserved.


/**
 * @fileoverview Test whether a captive portal is present and implemented
 *   via HTTP.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.CaptivePortalHttpTest');

goog.require('ccd.HostType');
goog.require('ccd.Test');
goog.require('ccd.TestId');
goog.require('ccd.TestResult');
goog.require('ccd.TestVerdict');



/**
 * @constructor
 * @extends {ccd.Test}
 */
ccd.CaptivePortalHttpTest = function() {
  goog.base(this);
  this.testResult = new ccd.TestResult(ccd.TestId.CAPTIVE_PORTAL_HTTP);
  this.numTestsCompleted_ = 0;
  this.fullResponseLength_ = new Array();
  this.responseCode_ = new Array();
  this.xhr_ = new Array();
};
goog.inherits(ccd.CaptivePortalHttpTest, ccd.Test);


/**
 * @type {number}
 * @private
 */
ccd.CaptivePortalHttpTest.prototype.numTestsCompleted_ = 0;


/**
 * @type {Array.<XMLHttpRequest>}
 * @private
 */
ccd.CaptivePortalHttpTest.prototype.xhr_ = null;


/**
 * type {number}
 * @private
 */
ccd.CaptivePortalHttpTest.timeoutId_ = 0;


/**
 * @type {Array.<Array.<ccd.HostType, string>>}
 * @private
 */
// TODO: create a generic hostname array
ccd.CaptivePortalHttpTest.prototype.hostnamesToQuery_ = [
  [ccd.HostType.GOOGLE, 'www.google.com/generate_204'],

  // TODO: mysteriously doesn't work
  //[ccd.HostType.EXTERNAL, 'facebook.com'],

  [ccd.HostType.EXTERNAL, 'www.yahoo.com']
];


/**
 * @type {Array.<number>}
 * @private
 */
ccd.CaptivePortalHttpTest.prototype.responseCode_ = null;


/**
 * @type {Array.<number>}
 * @private
 */
ccd.CaptivePortalHttpTest.prototype.fullResponseLength_ = null;


/**
 * Perform cleanup work and then execute the final callback function.
 */
ccd.CaptivePortalHttpTest.prototype.executeCallback = function() {
  this.callbackFnc(this.testResult);
};


/**
 * Analyze the test results to determine whether a captive portal via HTTP
 *   is present.
 */
ccd.CaptivePortalHttpTest.prototype.analyzeResults = function() {
  // start by assuming that everything is working properly
  this.testResult.setTestVerdict(ccd.TestVerdict.NO_PROBLEM);
  this.testResult.setTitle('Internet Traffic Not Blocked by ' +
      'Captive Portal (HTTP)');
  this.testResult.setSubtitle('No captive portal found. A captive portal ' +
      'is a website that a network requires its users to view and interact ' +
      'with before being granted access to browse the Internet freely.');

  // check whether Google's /generate_204 returns anything but a 204 status
  // if so, there is probably a HTTP captive portal
  for (var i = 0; i < this.hostnamesToQuery_.length; i++) {
    if (this.hostnamesToQuery_[i][0] == ccd.HostType.GOOGLE) {
      if (this.responseCode_[i] != 204) {
        this.testResult.setTitle('Internet Traffic Blocked by ' +
            'Captive Portal (HTTP)');
        this.testResult.setSubtitle('A captive portal is a website that a ' +
            'network requires its users to view and interact with before ' +
            'being granted access to browse the Internet freely. A captive ' +
            'portal was found on your network, meaning unrestricted access ' +
            'to the Internet is blocked. You can learn more about how to ' +
            'fix this by clicking "More Information".');
        this.testResult.setTestVerdict(ccd.TestVerdict.PROBLEM);
        this.testResult.addLogRecord('Query ' + i + ' to Google/generate_204 ' +
            'did not return status code 204 but instead returned status code ' +
            this.responseCode_[i]);
        this.testResult.addLogRecord('Query ' + i + ' returned length ' +
            '(headers + content) ' + this.fullResponseLength_[i]);
      }
    }
  }

  // check whether HTTP responses returned differing
  for (var i = 1; i < this.hostnamesToQuery_.length; i++) {
    if (this.hostnamesToQuery_[i][0] == ccd.HostType.GOOGLE) return;

    // if the response length for a non-Google host is very similar,
    //   then there is likely a HTTP-based captive portal
    if (this.fullResponseLength_[i] - this.fullResponseLength_[i - 1] < 20) {
      this.testResult.setTitle('Internet Traffic May be Blocked by ' +
          'Captive Portal (HTTP)');
      this.testResult.setSubtitle('A captive portal is a website that a ' +
          'network requires its users to view and interact with before ' +
          'being granted access to browse the Internet freely. A captive ' +
          'portal appears to be on your network, meaning unrestricted ' +
          'access to the Internet is probably blocked. You can learn more ' +
          'about this as well as how to fix it by clicking ' +
          '"More Information".');
      this.testResult.setTestVerdict(ccd.TestVerdict.POTENTIAL_PROBLEM);
      this.testResult.addLogRecord('Potential problem detected as response ' +
          'length for host ' + i + ' and host ' + (i - 1) +
          ' are very similar in length, indicating the possibility of a ' +
          'HTTP-based captive portal.');
    }
  }
};


/**
 * @param {number} requestNum The number of the HTTP request.
 * @private
 */
ccd.CaptivePortalHttpTest.prototype.responseReceived_ = function(requestNum) {
  this.testResult.addLogRecord('Began processing response number ' +
      requestNum + '.');

  var responseHeaders =
      this.xhr_[requestNum].getAllResponseHeaders().split('\n');
  // remove final newline of HTTP response
  responseHeaders.pop();

  var responseText = this.xhr_[requestNum].responseText;
  var responseCode = this.xhr_[requestNum].status;
  var responseLength =
      this.xhr_[requestNum].getAllResponseHeaders().length +
      responseText.length;
  this.fullResponseLength_.push(responseLength);
  this.responseCode_.push(responseCode);

  this.testResult.addLogRecord('Response ' + requestNum + ' received. Full ' +
      'Response length: ' + responseText.length);
  this.testResult.addLogRecord('Response ' + requestNum + ' -- HTTP response ' +
      'code: ' + responseCode);

  for (var i = 0; i < responseHeaders.length; i++) {
    this.testResult.addLogRecord('Response ' + requestNum + ' -- ' +
        'Response Header ' + i + ': ' + responseHeaders[i]);
  }

  this.numTestsCompleted_ = requestNum + 1;
  window.clearTimeout(this.timeoutId_);
  if (this.numTestsCompleted_ < this.hostnamesToQuery_.length) {
    this.timeoutId_ = setTimeout(this.requestHostname_.bind(this),
                                 ccd.TestConfVars.XHR_SLEEP_MILSEC);
  } else {
    this.analyzeResults();
    this.executeCallback();
  }
};


/**
 * @param {number} requestNum The number of the HTTP request.
 * @param {ajax.XMLHttpRequestProgressEvent} progressEvent AJAX error event.
 * @private
 */
ccd.CaptivePortalHttpTest.prototype.requestError_ = function(requestNum, 
                                                             progressEvent) {
  this.testResult.addLogRecord('Error occurred in XHR request # ' + requestNum +
      '. XHR readyState: ' + this.xhr_[requestNum].readyState);
};


/**
 * Return a new XMLHttpRequest.
 * Implemented for efficient testing.
 * @return {XMLHttpRequest} New XHR object.
 * @private
 */
ccd.CaptivePortalHttpTest.prototype.newXhr_ = function() {
  return new XMLHttpRequest();
};


/**
 * @private
 */
ccd.CaptivePortalHttpTest.prototype.requestHostname_ = function() {
  var requestNum = this.numTestsCompleted_;
  this.xhr_[requestNum] = this.newXhr_();

  this.xhr_[requestNum].onabort = this.requestError_.bind(this, requestNum);
  this.xhr_[requestNum].onerror = this.requestError_.bind(this, requestNum);
  this.xhr_[requestNum].timeout = ccd.TestConfVars.XHR_TIMEOUT_MILSEC;

  // setup function to handle successful response
  var readyStateChange = function() {
    if ((this.xhr_[requestNum].readyState < 4)) return;

    this.testResult.addLogRecord('Received successful XHR response for ' +
        'request ' + requestNum);
    var boundFnc = this.responseReceived_.bind(this, requestNum);
    boundFnc();
  };

  this.xhr_[requestNum].onreadystatechange = readyStateChange.bind(this);

  var hostname = 'http://' + this.hostnamesToQuery_[requestNum][1];
  this.testResult.addLogRecord('About to issue XHR request # ' +
      requestNum + ' to: ' + hostname);
  this.xhr_[requestNum].open('GET', hostname);
  this.xhr_[requestNum].send();
};


/**
 * @param {function(this:ccd.TestsManager, ccd.TestResult)} callbackFnc
 *   Function to execute upon completion of test.
 */
ccd.CaptivePortalHttpTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;
  this.requestHostname_();
};
