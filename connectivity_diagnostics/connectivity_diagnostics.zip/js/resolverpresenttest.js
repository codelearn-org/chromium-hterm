

/**
 * @fileoverview Test whether a DNS resolver is available to the browser.
 * @author ebeach@google.com (Eric Beach)
 */


goog.provide('ccd.ResolverPresentTest');

goog.require('ccd.Test');
goog.require('ccd.TestId');
goog.require('ccd.TestResult');
goog.require('ccd.TestVerdict');



/**
 * Test whether a DNS resolver is available to the browser.
 * @constructor
 * @extends {ccd.Test}
 */
ccd.ResolverPresentTest = function() {
  goog.base(this);
  this.testResult = new ccd.TestResult(ccd.TestId.DNS_RESOLVER_PRESENT);
};
goog.inherits(ccd.ResolverPresentTest, ccd.Test);


/**
 * Analyze test results.
 * @see trunk/src/chrome/common/extensions/api/experimental_dns.idl
 * @param {chrome.experimental.dns.ResolveCallbackResolveInfo} resolverResult
 *   DNS query result.
 */
ccd.ResolverPresentTest.prototype.analyzeResults = function(resolverResult) {
  if (resolverResult.resultCode != undefined &&
      resolverResult.resultCode == 0) {
    this.testResult.setTitle('DNS Server Available');
    this.testResult.setSubtitle('Chrome found a DNS resolver that ' +
        'successfully translated a hostname (e.g., google.com) into an IP.');
    this.testResult.addLogRecord('Hostname Resolved to: ' +
        resolverResult.address);
    this.testResult.addLogRecord('Resolver returned status code ' +
        resolverResult.resultCode + ', no problem detected');
    this.testResult.setTestVerdict(ccd.TestVerdict.NO_PROBLEM);
  } else {
    this.testResult.setTitle('No Functioning DNS Server Available');
    this.testResult.setSubtitle('A DNS server translates a hostname ' +
        '(e.g., Google.com) into an IP. Since a ' +
        'browser must have an IP to connect to in order to load a website, ' +
        'the lack of a working DNS server means that Chrome cannot find the ' +
        'IP of the website you wish to visit. You do not have a working DNS ' +
        'server. You can learn more about how to fix this by clicking ' +
        '"More Information".');
    this.testResult.addLogRecord('Resolver returned status code ' +
        resolverResult.resultCode + ', problem detected');
    this.testResult.setTestVerdict(ccd.TestVerdict.PROBLEM);
  }
};


/**
 * Handle the results of a DNS query.
 * @param {chrome.experimental.dns.ResolveCallbackResolveInfo} resolverResult
 *   DNS query result.
 * @private
 */
ccd.ResolverPresentTest.prototype.resolveCallback_ = function(resolverResult) {
  if (resolverResult == undefined) {
    this.testResult.addLogRecord('Resolver did not return any object ' +
        '(even a record DNE entry), test did not complete.');
    this.testResult.setTestVerdict(ccd.TestVerdict.TEST_FAILURE_OCCURRED);
  } else {
    this.testResult.addLogRecord('Resolver returned a result, ' +
        'test completed');
    this.analyzeResults(resolverResult);
  }
  this.executeCallback();
};


/**
 * @override
 */
ccd.ResolverPresentTest.prototype.runTest = function(callbackFnc) {
  this.callbackFnc = callbackFnc;

  this.testResult.addLogRecord('About to begin attempting to resolve ' +
      'Google hostnames');

  var hostname = 'www.google.com';
  this.testResult.addLogRecord('Attempting to resolve hostname: ' + hostname);
  chrome.experimental.dns.resolve(hostname, this.resolveCallback_.bind(this));
};
