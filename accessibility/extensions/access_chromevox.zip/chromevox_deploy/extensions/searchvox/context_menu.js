// Copyright 2013 Google Inc. All Rights Reserved.

/**
 * @fileoverview Context Menu for Search.
 * @author peterxiao@google.com (Peter Xiao)
 */

goog.provide('cvox.SearchContextMenu');

goog.require('cvox.Search');
goog.require('cvox.SearchTool');

/**
 * @constructor
 */
cvox.SearchContextMenu = function() {
};

/* Globals */
var Command = {
  TOOLS: 'tools',
  ADS: 'ads',
  MAIN: 'main'
};

/**
 * Current focus Search is in.
 */
cvox.SearchContextMenu.currState = Command.MAIN;

/**
 * Handles context menu events.
 * @param {Event} evt Event received.
 */
cvox.SearchContextMenu.contextMenuHandler = function(evt) {
  var cmd = evt.detail['customCommand'];
  switch (cmd) {
  case Command.TOOLS:
    cvox.SearchContextMenu.focusTools();
    break;

  case Command.ADS:
    cvox.SearchContextMenu.focusAds();
    break;

  case Command.MAIN:
    cvox.SearchContextMenu.focusMain();
    break;
  }
};

/**
 * Handles key events.
 * @param {Event} evt Event received.
 * @return {boolean} True if key was handled, false otherwise.
 */
cvox.SearchContextMenu.keyhandler = function(evt) {
  var ret = false;
  /* TODO(peterxiao): Wait for better isKeyShortcut api. */
  if (evt.shiftKey || evt.ctrlKey || evt.altKey || evt.metaKey) {
    return false;
  }
  switch (cvox.SearchContextMenu.currState) {
  case Command.TOOLS:
    ret = cvox.SearchTool.keyhandler(evt);
    break;
  case Command.ADS:
  case Command.MAIN:
    ret = cvox.Search.keyhandler(evt);
    break;
  }
  return ret;
};

/**
 * Switch to main search results focus.
 */
cvox.SearchContextMenu.focusMain = function() {
  if (cvox.SearchContextMenu.currState === Command.TOOLS) {
    cvox.SearchTool.toggleMenu();
  }
  cvox.Search.populateWebResults();
  cvox.Search.index = 0;
  cvox.Search.syncToIndex();
  cvox.SearchContextMenu.currState = Command.MAIN;
};

/**
 * Switch to ads focus.
 */
cvox.SearchContextMenu.focusAds = function() {
  cvox.Search.populateAdResults();
  if (cvox.Search.results.length === 0) {
    cvox.SearchContextMenu.focusMain();
    return;
  }
  cvox.Search.index = 0;
  cvox.Search.syncToIndex();

  if (cvox.SearchContextMenu.currState === Command.TOOLS) {
    cvox.SearchTool.toggleMenu();
  }

  cvox.SearchContextMenu.currState = Command.ADS;
};

/**
 * Switch to tools focus.
 */
cvox.SearchContextMenu.focusTools = function() {
  if (cvox.SearchContextMenu.currState !== Command.TOOLS) {
    cvox.SearchTool.activateTools();
    cvox.SearchContextMenu.currState = Command.TOOLS;
  }
};

/**
 * Initializes the context menu.
 */
cvox.SearchContextMenu.init = function() {
  var ACTIONS = [
    { desc: 'Main Results', cmd: Command.MAIN },
    { desc: 'Search Tools', cmd: Command.TOOLS },
    { desc: 'Ads', cmd: Command.ADS }
  ];
  /* Attach ContextMenuActions. */
  var body = document.querySelector('body');
  body.setAttribute('contextMenuActions', JSON.stringify(ACTIONS));

  /* Listen for ContextMenu events. */
  body.addEventListener('cvoxUserEvent',
    cvox.SearchContextMenu.contextMenuHandler, true);

  window.addEventListener('keydown', cvox.SearchContextMenu.keyhandler, true);
  cvox.Search.init();
};

function cvoxApiExists() {
  return (typeof(cvox) != 'undefined') && cvox && cvox.Api;
}

function watchForCvoxLoad() {
  if (cvoxApiExists()) {
    cvox.SearchContextMenu.init();
  } else {
    window.setTimeout(watchForCvoxLoad, 500);
  }
}

watchForCvoxLoad();
